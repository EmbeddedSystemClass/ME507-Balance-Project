var searchData=
[
  ['set_5fgains',['set_gains',['../classBalance.html#aa89fe806776052b38b9ae5e49577f1f3',1,'Balance']]],
  ['set_5fsetpoint',['set_setpoint',['../classBalance.html#a6ad17cb4f844490c1d127a7006457f41',1,'Balance']]],
  ['setactuation',['setActuation',['../classMotor.html#a365fc68f12da73850f0d2c122e70d0ec',1,'Motor']]]
];
