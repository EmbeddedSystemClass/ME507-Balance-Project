var searchData=
[
  ['in1_5fchan',['IN1_chan',['../classMotor.html#a25e145c9db093eba575a76db11429cd0',1,'Motor']]],
  ['in2_5fchan',['IN2_chan',['../classMotor.html#adf38bf5b263a743bb4ce188cc1188c7b',1,'Motor']]]
];
