var searchData=
[
  ['set_5fx',['set_x',['../classBalance.html#a94ea3cf125d0741f620c76dd851e50d1',1,'Balance']]],
  ['set_5fy',['set_y',['../classBalance.html#a4c1a5b2446c3cb493227db2b4492f18a',1,'Balance']]]
];
